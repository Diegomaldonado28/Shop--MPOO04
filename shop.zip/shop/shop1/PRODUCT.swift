//
//  PRODUCT.swift
//  shop1
//
//  Created by Usuario invitado on 4/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation
import UIKit

struct Campo {
    
    var Name: String
    var Price: String
    var Desc: String
    var Image: UIImage
}
